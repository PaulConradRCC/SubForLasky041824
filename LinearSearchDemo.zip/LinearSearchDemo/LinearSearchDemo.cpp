/* 
 * File:   LinearSearchDemo.cpp
 * Author: pconrad
 *
 * Created on April 18, 2024, 6:38 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

void PrintArray(int array[], int number_of_elements)
{
    for(int index=0; index<(number_of_elements-1); index++)
        cout << array[index] << ", ";
    cout << array[number_of_elements-1] << endl;
}

void BubbleSort(int array[], int number_of_elements)
{
    int number_of_swaps = 0;
    int temp;
    bool swapped;
        
    do {
        swapped = false;
        for(int index = 0; index<(number_of_elements-1); index++)
        {
            if ( array[index] > array[index+1] )
            {
                number_of_swaps++;
                temp = array[index];
                array[index] = array[index+1];
                array[index+1] = temp;
                swapped = true;      
            }
        }
    } while(swapped == true);
    cout << "BubbleSort: " << number_of_swaps << " swaps done." << endl;
}

int LinearSearch(int array[], int number_of_elements, int search_value)
{
    int comparison_count = 0;
    bool found = false; // flag for was the value found or not...
    int position = -1, index = 0;   // if position == -1, value not found; otherwise position holds
                                    // the index of where the value is located
    
    while( (index<number_of_elements) && (found == false) )
    {
        comparison_count++;
        if ( array[index] == search_value )
        {
            found = true;
            position = index;
        }
        index++;
    }    
    cout << "LinearSearch: comparison_count = " << comparison_count << endl;
    
    return position;
}

int LinearSearch(int array[], int number_of_elements, int search_value, int starting_index)
{
    bool found = false; // flag for was the value found or not...
    int position = -1, index = starting_index;   // if position == -1, value not found; otherwise position holds
                                    // the index of where the value is located
    
    while( (index<number_of_elements) && (found == false) )
    {
        if ( array[index] == search_value )
        {
            found = true;
            position = index;
        }
        index++;
    }
    
    return position;
}

int BinarySearch(int array[], int number_of_elements, int search_value )
{
    int comparison_count = 0;
    int first = 0, last = number_of_elements-1, middle, position = -1;
    bool found = false;
    
    while( !found && first <= last )
    {
        comparison_count++;
        middle = (first + last) / 2;
        
        if ( array[middle] == search_value )
        {
            found = true;
            position = middle;
        }
        else if ( array[middle] > search_value )
            last = middle-1;
        else
            first = middle+1;
    }
    cout << "BinarySearch: comparison_count = " << comparison_count << endl;
    
    return position;
}

/*int BinarySearch(int array[], int number_of_elements, int search_value, int starting_index )
{
    int comparison_count = 0;
    int first = starting_index, last = number_of_elements-1, middle, position = -1;
    bool found = false;
    
    while( !found && first <= last )
    {
        comparison_count++;
        middle = (first + last) / 2;
        
        if ( array[middle] == search_value )
        {
            found = true;
            position = middle;
        }
        else if ( array[middle] > search_value )
            last = middle-1;
        else
            first = middle+1;
    }
    cout << "BinarySearch: comparison_count = " << comparison_count << endl;
    
    return position;
}
*/

int main(int argc, char** argv) {

    int number_of_items;
    
    do {
        cout << "How many values for the array? ";
        cin >> number_of_items;

        if ( number_of_items < 1 )
            cout << "ERROR: number of array items must be greater than or equal to 1." << endl;
    } while( number_of_items < 1 );
    
    int my_array[number_of_items];
    
    for(int index=0; index<number_of_items; index++)
    {
        cout << "Enter value for my_array[" << index << "]: ";
        cin >> my_array[index];
    }
    
    int value_to_search_for;
    
    cout << "Enter a value that you wish to find: ";
    cin >> value_to_search_for;
    
    int search_index_result = LinearSearch(my_array, number_of_items, value_to_search_for);
    
    if ( search_index_result != -1 )
    {
        cout << "Found the value " << value_to_search_for << " at index " << search_index_result << endl;
        do {
            search_index_result = LinearSearch(my_array, number_of_items, value_to_search_for, search_index_result+1 );
            
            if ( search_index_result != -1 )
                cout << "Found the value " << value_to_search_for << " at index " << search_index_result << endl;
        } while(search_index_result != -1);
    }
    else
        cout << "Did not find " << value_to_search_for << " in the array." << endl;
    
    BubbleSort(my_array, number_of_items);
    
    cout << "my_array after BubbleSort:" << endl;
        
    PrintArray(my_array, number_of_items);
    
    search_index_result = BinarySearch(my_array, number_of_items, value_to_search_for);
    
    if ( search_index_result != -1 )
    {
        cout << "Found the value " << value_to_search_for << " at index " << search_index_result << endl;
        /*do {
            search_index_result = BinarySearch(my_array, number_of_items, value_to_search_for, search_index_result+1 );
            
            if ( search_index_result != -1 )
                cout << "Found the value " << value_to_search_for << " at index " << search_index_result << endl;
        } while(search_index_result != -1);
         */
    }
    else
        cout << "Did not find " << value_to_search_for << " in the array." << endl;
    
    return 0;
}

